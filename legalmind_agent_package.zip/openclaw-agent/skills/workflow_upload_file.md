---
command-dispatch: legalmind.evidence.upload
---
# Upload File

Upload a file or directory to the LegalMind Engine. Directories are automatically zipped.
