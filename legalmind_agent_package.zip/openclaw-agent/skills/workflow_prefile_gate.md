---
command-dispatch: legalmind.prefile.run
---
# Prefile Gate

Run the full pre-filing gate check (citations + claims).
