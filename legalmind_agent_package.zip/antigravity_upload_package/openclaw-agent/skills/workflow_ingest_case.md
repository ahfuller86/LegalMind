---
command-dispatch: legalmind.evidence.ingest
---
# Ingest Case

Ingest a file into the evidence record.
