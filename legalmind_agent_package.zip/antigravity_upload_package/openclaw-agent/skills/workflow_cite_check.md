---
command-dispatch: legalmind.citations.verify_batch
---
# Cite Check

Verify legal citations in the text.
