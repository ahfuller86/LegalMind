---
command-dispatch: legalmind.evidence.upload
---
# Upload File

Upload a file or folder from the local environment to the Engine for processing. Folders are automatically zipped.
